---
name: "\U0001F4AC Question"
about: Submit a question related to UI Kitten
title: ''
labels: ":grey_question: Help wanted"
assignees: ''

---

<!-- Love UI Kitten? Please leave feedback: 👉  https://github.com/akveo/react-native-ui-kitten/issues/657 -->

## 💬 Question

## UI Kitten and Eva version

| Package      | Version |
| ----------- | ----------- |
| @eva-design/eva      |        |
| @ui-kitten/components   |         |
