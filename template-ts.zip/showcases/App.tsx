import App from './app/app.component';

// eslint-disable-next-line no-restricted-syntax
export default App;
