import React from 'react';
import { Spinner } from '@ui-kitten/components';

export const SpinnerSimpleUsageShowcase = (): React.ReactElement => (
  <Spinner />
);
