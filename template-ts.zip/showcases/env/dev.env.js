const path = require('path');

module.exports = {
  ENV: 'dev',
  EVA_PATH: path.resolve(__dirname, '../../../../eva/packages'),
};
