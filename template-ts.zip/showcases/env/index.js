const path = require('path');

module.exports = {
  ENV: 'prod',
  EVA_PATH: path.resolve(__dirname, '../../../node_modules/@eva-design'),
};
