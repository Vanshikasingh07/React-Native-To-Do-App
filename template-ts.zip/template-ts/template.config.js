module.exports = {
  placeholderName: 'HelloWorld',
  templateDir: './template',
}
